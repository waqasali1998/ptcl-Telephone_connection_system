/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package telephone_connection_system;

/**
 *
 * @author Rehan ul haq
 */
public class Telephone_connection_system {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
