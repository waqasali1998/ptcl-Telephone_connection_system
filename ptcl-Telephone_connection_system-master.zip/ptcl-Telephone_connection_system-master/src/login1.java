/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rehan ul haq
 */
public class login1 {
 
    public static int iLogin;
}
